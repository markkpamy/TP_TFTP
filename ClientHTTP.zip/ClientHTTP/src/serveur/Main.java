package serveur;

import java.io.IOException;

public class Main 
{
	// CLASSE MAIN DU SERVEUR
	//EXECUTER EN PREMIER
	public static void main(String[] args) throws IOException 
	{
		try {
			ServeurHTTP serveurHTTP = new ServeurHTTP();
			serveurHTTP.loadConnexion();
			
		}   catch(Exception e){
			System.out.println("Erreur de l'application : "+e.getMessage());
		}
	}
}
