package serveur;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServeurHTTP
{
	private ServerSocket socketServeur;
	private Socket clientSocket;

	public ServeurHTTP()
	{
		System.out.println("Initialisation du serveur...");
		try {
			socketServeur=new ServerSocket(2046);
		} catch (IOException e) { 
			System.out.println("Impossible de lancer le serveur primaire");
		}
		System.out.println("Serveur HTTP primaire pret!");
	}

	public void loadConnexion()
	{
		try {
			while(true) {
				clientSocket = socketServeur.accept();           
				ServeurConcurrent sc = new ServeurConcurrent(clientSocket); 
				sc.start();
			}
		} catch (IOException e) { 
			System.out.println("Impossible de lancer le serveur secondaire");
		} 
	}

}
