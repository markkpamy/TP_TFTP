package serveur;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ServeurConcurrent extends Thread {
	private Socket socketConnection;

	public ServeurConcurrent(Socket connection) {
		this.socketConnection = connection;
	}

	public void run() {

		try {
			//////// CREATION DES FLUX IN ET OUT ////////
			DataInputStream inFromClient = null;
			inFromClient = new DataInputStream(socketConnection.getInputStream());

			DataOutputStream outToClient = null;
			outToClient = new DataOutputStream(socketConnection.getOutputStream());

			recevoirGet(inFromClient, outToClient);

		} catch (IOException e) {
			System.out.println("Probleme de reseau (run)");
		}

	}

	public boolean recevoirGet(DataInputStream inFromClient, DataOutputStream outToClient) {
		try {
			
			//////RECEPTION DE LA REQUETE//////
			String[] input = inFromClient.readLine().split(" ");
			String[] path = input[1].split("/");
			String chemin = "";
			for (int i = 2; i < path.length; i++) {
				if (i != 2)
					chemin += "/";

				chemin += path[i];
			}
			
			///////  SI LA REQUETE EST BIEN UN GET ///////
			if (input[0].equals("GET")) {
				
				/////// SI L'ADRESSE EST BIEN CELLE DU SERVEUR ///////
				if (path.length > 1 
				&& (path[1].equals(InetAddress.getLocalHost().getHostAddress())
					|| path[1].equals(InetAddress.getLoopbackAddress().getHostAddress()))) {

					System.out.println("DEMANDE DE GET");
					
					/////// ON CREE LE GET RESPONSE ///////
					String command = input[2] + " 200 OK";

					Date date = new Date();
					
					String date1 = "Date: " + date;
					String connexion = input[3] + " " + input[4];

					String server = ("Server: " + this.socketConnection.getInetAddress());

					String typeFichier = "inconnu";
					if(chemin.split("\\.").length > 1)
						typeFichier = chemin.split("\\.")[1];
					String contentType = "Content-Type: " + typeFichier;
					System.out.println(typeFichier);
					
					File file = new File(chemin);
					if (!file.exists())
		            {
						////// SI L'ADRESSE N'EST PAS CORRECTEMENT RENTREE ///////
						command = input[2] + " 404";

						outToClient.writeBytes(command+"\n");
						outToClient.flush();
						
						FileInputStream fich404 = new FileInputStream("404.html");
						byte bufferEnvoi[] = new byte[133];
						fich404.read(bufferEnvoi);
						fich404.close();
						outToClient.write(bufferEnvoi);
						
						System.out.println("Page 404 envoy�e.");
						socketConnection.close();
		                return false;
		            }
					int size = (int) file.length(); //On prend la longueur du fichier � envoyer pour le header

					FileInputStream fichHTML = new FileInputStream(chemin);
					byte bufferEnvoi[] = new byte[size];
					
					/////// LECTURE DU FICHIER ///////
					fichHTML.read(bufferEnvoi);
					fichHTML.close();

					String contentLength = "Content-Length: " + size;

					String getResp = command + "\n" + date1 + "\n" + connexion
							+ "\n" + server + "\n" + contentType + "\n"
							+ contentLength;

					/////// ENVOI DU HEADER ET DU FICHIER ///////
					outToClient.writeBytes(getResp + "\n\n");
					outToClient.flush();

					outToClient.write(bufferEnvoi);
					outToClient.close();

				}
			} else {
				
				/////// SI LA COMMANDE N'EST PAS UN GET ///////
				String command = input[2] + " 504";
				outToClient.writeChars(command);
				outToClient.flush();
				

				FileInputStream fich504 = new FileInputStream("504.html");
				byte bufferEnvoi[] = new byte[133];
				fich504.read(bufferEnvoi);
				fich504.close();
				outToClient.write(bufferEnvoi);
				
				System.out.println("Page 504 envoy�e.");
				
				socketConnection.close();
			}
			socketConnection.close();

			return true;

		} catch (IOException e) {
			System.out.println("Probleme de reseau (recevoirGet)");
			return false;
		}
	}
}
