package client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
	
	Socket clientSocket;
	InetAddress adresseIp;
	String fichier;
	String requete;
	String connec;
	
	public String contenu;
	public String entete;
	public String typeFich;
	
	public Client() {
		try {
			connec = "Connection: keep-alive";
			getFromClavier();
			adresseIp = java.net.InetAddress.getByName("127.0.0.1");
			clientSocket = new Socket(adresseIp,2046);
			runClient();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public Client(String p_requete, String p_adresse, String p_fichier)
	{
		typeFich = "";
		contenu = "";
		entete = "";
		connec = "Connection: keep-alive";
		try {
			adresseIp = java.net.InetAddress.getByName(p_adresse);
			fichier = p_fichier;
			requete = p_requete;
			clientSocket = new Socket(adresseIp,2046);
			runClient();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void getFromClavier() {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ecrivez votre requete.\n");
		requete = sc.nextLine();
		
		System.out.println("Garder la connexion? y/n");
		connec = sc.nextLine();
		if (connec.equals("y"))
			connec = "Connection: keep-alive";
		else
			connec = "Connection: close";
		
		sc.close();
	}
	
	@SuppressWarnings("deprecation")
	private void runClient() throws IOException {

		/////// CREATION DES FLUX ENTREE ET SORTIE ///////
		DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
		DataInputStream inFromServer = new DataInputStream(clientSocket.getInputStream());
		
		//Ecriture de la requete GET dans le flux
		outToServer.writeBytes(requete+" "+connec+"\n");
		outToServer.flush();

		String temp;
		String getResp="";
		String length ="";
		
		String getAuth = inFromServer.readLine();
		String stat_line[] = getAuth.split(" ");
		
		//SI LA REPONSE EST OK, on lit la suite de l'header
		if(stat_line.length > 1) {
			if (stat_line[1].equals("200")) {
				getResp = getAuth+"\n";
				
				while (!(temp = inFromServer.readLine()).equals("")) {	
					
					if (temp.contains("Length"))
						if(temp.split(": ").length > 1)
							length = (temp.split(": "))[1];
					
					getResp += temp + "\n";
				}
				entete = getResp;
				
				System.out.println("Received: \n" + getResp);
				
				//CREATION DU BUFFER DE RECEP
				byte data[] =new byte[Integer.parseInt(length)];
				
				//RECEPTION DU FICHIER
				for(int i =0; i<data.length;i++)
					data[i] = inFromServer.readByte();
				inFromServer.close();
				
				//CREATION DU FICHIER A LA RACINE
				String nomFichierSplit = "inconnu.html";
				if(requete.split("/").length > 2)
				nomFichierSplit = requete.split("/")[2].split(" ")[0];
				File file = new File("RECU"+nomFichierSplit);
				file.createNewFile();
				
				typeFich = nomFichierSplit;
				
				//ECRITURE DU CONTENU RECU DANS LE FICHIER
				FileOutputStream fop = new FileOutputStream(file);
				fop.write(data);
				contenu = new String(data);
				fop.close();
				
				System.out.println("TRANSFERT REUSSI");
				clientSocket.close();
			}
			else if (stat_line[1].equals("404")) {
				System.out.println("404 NOT FOUND : "+getAuth);
				byte data[] = new byte[133];
				
				for(int i=0;i<data.length;i++)
					data[i] = inFromServer.readByte();
				inFromServer.close();
				
				File file = new File("404.html");
				file.createNewFile();
				
				FileOutputStream fop = new FileOutputStream(file);
				fop.write(data);
				contenu = new String(data);
				fop.close();
				clientSocket.close();
				
			}
		}
	}
}
