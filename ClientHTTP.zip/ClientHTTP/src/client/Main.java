package client;

public class Main {
	
	// CLASSE MAIN DU CLIENT
	// A LANCER POUR TESTER DANS LA CONSOLE
	// SINON LANCER LA CLASSE VUE
	public static void main(String[] args) {
		new Client();
	}
}
